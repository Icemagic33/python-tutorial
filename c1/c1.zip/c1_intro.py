# Variable
'''
Anything
whatever
'''

# Numbers
# 1. Integer
# (type) (variable name) = (value)
# ex. int a = 16;
a = 16
print(type(a))
b = -3
print(type(b))

# 2. Real Number
# type: float32, float64(double)
c = 3.14
print(type(c))

# Calculate
# We have 5 apples and 3 pears. How many fruit do we have in total?
# print(5+3)
apple = 5
pear = 3
fruit = apple + pear
print(fruit)

num = apple - pear
print(num)

# 3 pairs of shoes
pair = 2
shoes = 3
total_shoe = pair * shoes
print(total_shoe)


print(4/2)
print(type(4))
print(type(2))
print(type(4/2))
